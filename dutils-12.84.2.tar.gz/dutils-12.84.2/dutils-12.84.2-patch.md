

#
# dutils patch notes

## Version 12.84.2

## Developer(s):
- **formik**
- **deadly**
- **benitas**




## Notes

- **_New_** `{prefix}blackcheat.reset` **command which reset's BLACKCHEAT's Data and prepares you for a new game
with a fresh slate.**

#

